const API_URL = 'http://localhost:5259/api';

// Carrinho armazenado na memória RAM do navegador
let db_carrinho = [];

export const api = {
  // --- AUTENTICAÇÃO ---
  register: async (userData) => {
    try {
      const response = await fetch(`${API_URL}/Auth/register`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({
          Nome: userData.nome,
          Email: userData.email,
          Senha: userData.senha
          // CPF removido - não é mais enviado
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Erro ao criar conta');
      }

      return await response.json();
    } catch (error) {
      console.error('Erro no registro:', error);
      throw error;
    }
  },

  login: async (email, senha) => {
    try {
      const response = await fetch(`${API_URL}/Auth/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({
          Email: email,
          Senha: senha
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Email ou senha inválidos');
      }

      const data = await response.json();
      
      // Salva os dados do usuário no localStorage
      localStorage.setItem('user', JSON.stringify(data.user));
      
      return data;
    } catch (error) {
      console.error('Erro no login:', error);
      throw error;
    }
  },

  checkEmail: async (email) => {
    try {
      const response = await fetch(`${API_URL}/Auth/check-email`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ Email: email }),
      });

      if (!response.ok) {
        return { exists: false };
      }

      return await response.json();
    } catch (error) {
      console.error('Erro ao verificar email:', error);
      return { exists: false };
    }
  },

  getCurrentUser: () => {
    const userStr = localStorage.getItem('user');
    return userStr ? JSON.parse(userStr) : null;
  },

  logout: () => {
    localStorage.removeItem('user');
    db_carrinho = []; // Limpa o carrinho ao fazer logout
  },

  // --- PRODUTOS ---
  getProdutos: async () => {
    try {
      const response = await fetch(`${API_URL}/Produto`);
      if (!response.ok) throw new Error('Erro ao buscar produtos');
      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Erro:', error);
      return [];
    }
  },
  
  getProduto: async (id) => {
    try {
      const response = await fetch(`${API_URL}/Produto/${id}`);
      if (!response.ok) throw new Error('Produto não encontrado');
      return await response.json();
    } catch (error) {
      throw new Error("Produto não encontrado");
    }
  },
  
  createProduto: async (produto) => {
    try {
      const response = await fetch(`${API_URL}/Produto`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(produto),
      });
      if (!response.ok) throw new Error('Erro ao criar produto');
      return await response.json();
    } catch (error) {
      console.error('Erro ao criar produto:', error);
      throw error;
    }
  },
  
  // --- CARRINHO ---
  adicionarAoCarrinho: async (produtoId, quantidade = 1) => { 
    return new Promise(async (resolve, reject) => {
      try {
        const produto = await api.getProduto(produtoId);
        
        if (!produto) {
          reject(new Error("Produto não existe no banco de dados"));
          return;
        }

        const itemExistente = db_carrinho.find(item => item.id === produtoId);
        
        if (itemExistente) {
          itemExistente.quantity += quantidade;
        } else {
          db_carrinho.push({
            ...produto,
            quantity: quantidade
          });
        }
        
        resolve(db_carrinho);
      } catch (error) {
        reject(error);
      }
    });
  },

  getCarrinho: async () => {
    return new Promise((resolve) => {
      resolve(db_carrinho);
    });
  },

  removerDoCarrinho: async (itemId) => {
    return new Promise((resolve) => {
      db_carrinho = db_carrinho.filter(item => item.id !== itemId);
      resolve(db_carrinho);
    });
  },
};