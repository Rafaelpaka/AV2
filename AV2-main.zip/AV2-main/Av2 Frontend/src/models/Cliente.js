export class Cliente {
    constructor(name, email, cpf, phone) {
        this.name = name;
        this.email = email;
        this.cpf = cpf;
        this.phone = phone;
    }
    validar() {
        if (!this.email.includes('@')) throw new Error("E-mail inválido.");
        return true;
    }
}