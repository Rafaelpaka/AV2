export class Pagamento {
    constructor(valor) { this.valor = valor; }
    processar() { throw new Error("Método abstrato"); }
}