export class Carrinho {
    constructor() { this.itens = []; }
    adicionarItem(produto, quantidade) { this.itens.push({ produto, quantidade }); }
    calcularTotal() { return this.itens.reduce((t, i) => t + (i.produto.price * i.quantidade), 0); }
}