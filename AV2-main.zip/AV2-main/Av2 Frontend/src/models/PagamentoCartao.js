import { Pagamento } from './Pagamento.js';
export class PagamentoCartao extends Pagamento {
    constructor(valor, numero, titular) {
        super(valor);
        this.numero = numero;
        this.titular = titular;
    }
    processar() { return true; }
}