export class Pedido {
    constructor(cliente, carrinho, pagamento) {
        this.cliente = cliente;
        this.carrinho = carrinho;
        this.pagamento = pagamento;
        this.numero = Math.floor(Math.random() * 99999);
    }
    finalizar() { return this.pagamento.processar(); }
}