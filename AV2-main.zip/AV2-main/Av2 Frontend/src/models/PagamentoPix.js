import { Pagamento } from './Pagamento.js';
export class PagamentoPix extends Pagamento {
    processar() { return true; }
}