namespace AV2.Application.DTOs.ClienteDTOs
{
    public class ClienteResponseDTO
    {
        public int IdCliente { get; set; }
        public required string Nome { get; set; }
        public required string Email { get; set; }
    }
}