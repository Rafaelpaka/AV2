namespace AV2.Application.DTOs.CarrinhoDTOs
{
    public class CarrinhoCreateDTO
    {
        public int IdCliente { get; set; }
    }
}