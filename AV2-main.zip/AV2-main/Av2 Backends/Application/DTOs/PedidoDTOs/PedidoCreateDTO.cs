namespace AV2.Application.DTOs.PedidoDTOs
{
    public class PedidoCreateDTO
    {
        public int IdCarrinho { get; set; }
    }
}