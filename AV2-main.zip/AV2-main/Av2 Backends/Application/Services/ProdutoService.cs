using AV2.Domain.Entities;
using AV2.Domain.Interfaces;
using AV2.Domain.ValueObjects;

namespace AV2.Application.Services
{
    public class ProdutoService
    {
        private readonly IProdutoRepository _produtoRepository;

        public ProdutoService(IProdutoRepository produtoRepository)
        {
            _produtoRepository = produtoRepository;
        }

        public Produto ObterPorId(int id)
        {
            return _produtoRepository.ObterPorId(id);
        }

        public IEnumerable<Produto> ObterTodos()
        {
            return _produtoRepository.ObterTodos();
        }

        public IEnumerable<Produto> ObterPorCategoria(string categoria)
        {
            return _produtoRepository.ObterPorCategoria(categoria);
        }

        public void CriarProduto(string nome, string descricao, decimal preco, string categoria, int estoque, string image = null, double rating = 0, int reviews = 0)
        {
            var dinheiro = Dinheiro.Create(preco);
            var produto = Produto.Create(nome, descricao, dinheiro, categoria, estoque, image, rating, reviews);
            _produtoRepository.Adicionar(produto);
        }

        public void AtualizarProduto(Produto produto)
        {
            _produtoRepository.Atualizar(produto);
        }

        public void RemoverProduto(int id)
        {
            _produtoRepository.Remover(id);
        }

        public void AdicionarEstoque(int id, int quantidade)
        {
            var produto = _produtoRepository.ObterPorId(id);
            if (produto == null)
                throw new Exception("Produto não encontrado");

            produto.AdicionarEstoque(quantidade);
            _produtoRepository.Atualizar(produto);
        }

        public void RemoverEstoque(int id, int quantidade)
        {
            var produto = _produtoRepository.ObterPorId(id);
            if (produto == null)
                throw new Exception("Produto não encontrado");

            produto.RemoverEstoque(quantidade);
            _produtoRepository.Atualizar(produto);
        }
    }
}