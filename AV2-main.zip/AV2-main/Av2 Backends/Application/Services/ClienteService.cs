using System;
using System.Collections.Generic;
using System.Linq;
using AV2.Domain.Entities;
using AV2.Domain.Interfaces;
using AV2.Domain.ValueObjects;
using AV2.Application.DTOs.ClienteDTOs;

namespace AV2.Application.Services
{
    public class ClienteService
    {
        private readonly IClienteRepository _clienteRepo;

        public ClienteService(IClienteRepository clienteRepo)
        {
            _clienteRepo = clienteRepo;
        }

        public ClienteResponseDTO CriarCliente(ClienteCreateDTO dto)
        {
            try
            {
                Console.WriteLine("=== INICIANDO CRIAÇÃO DE CLIENTE ===");
                
                // Validações básicas
                if (dto == null)
                {
                    Console.WriteLine("ERRO: DTO é nulo");
                    throw new ArgumentNullException(nameof(dto), "Dados do cliente não podem ser nulos");
                }

                Console.WriteLine($"DTO recebido - Nome: {dto.Nome}, Email: {dto.Email}, Senha: {(string.IsNullOrEmpty(dto.Senha) ? "vazia" : "preenchida")}");

                if (string.IsNullOrWhiteSpace(dto.Nome))
                {
                    Console.WriteLine("ERRO: Nome vazio");
                    throw new Exception("Nome é obrigatório");
                }

                if (string.IsNullOrWhiteSpace(dto.Email))
                {
                    Console.WriteLine("ERRO: Email vazio");
                    throw new Exception("Email é obrigatório");
                }

                if (string.IsNullOrWhiteSpace(dto.Senha))
                {
                    Console.WriteLine("ERRO: Senha vazia");
                    throw new Exception("Senha é obrigatória");
                }

                // Verificar se _clienteRepo está nulo
                if (_clienteRepo == null)
                {
                    Console.WriteLine("ERRO CRÍTICO: _clienteRepo é nulo!");
                    throw new Exception("Repositório de clientes não foi inicializado");
                }

                Console.WriteLine("Verificando se email já existe...");
                // Verificar se email já existe
                if (EmailJaExiste(dto.Email))
                {
                    Console.WriteLine($"ERRO: Email {dto.Email} já cadastrado");
                    throw new Exception("Este email já está cadastrado");
                }

                Console.WriteLine("Criando objeto Email...");
                // Criar Value Objects necessários
                Email email = null;
                try
                {
                    email = Email.Create(dto.Email);
                    Console.WriteLine($"Email criado com sucesso: {email?.Endereco}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"ERRO ao criar Email: {ex.Message}");
                    throw new Exception($"Email inválido: {ex.Message}");
                }
                
                Console.WriteLine("Processando CPF (opcional)...");
                // Tentar criar CPF se fornecido (opcional)
                CPF cpf = null;
                if (!string.IsNullOrWhiteSpace(dto.CPF))
                {
                    try
                    {
                        cpf = CPF.Create(dto.CPF);
                        Console.WriteLine("CPF criado com sucesso");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"CPF inválido, continuando sem CPF: {ex.Message}");
                        cpf = null;
                    }
                }
                else
                {
                    Console.WriteLine("CPF não fornecido (null/vazio)");
                }
                
                Console.WriteLine("Processando Endereço (opcional)...");
                // Criar endereço se fornecido
                Domain.ValueObjects.Endereco? endereco = null;
                if (!string.IsNullOrEmpty(dto.Logradouro))
                {
                    try
                    {
                        endereco = Domain.ValueObjects.Endereco.Create(
                            dto.Logradouro,
                            dto.Numero ?? "",
                            dto.Bairro ?? "",
                            dto.Cidade ?? "",
                            dto.Estado ?? "",
                            dto.CEP ?? "",
                            dto.Complemento
                        );
                        Console.WriteLine("Endereço criado com sucesso");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"ERRO ao criar endereço: {ex.Message}");
                        throw;
                    }
                }
                else
                {
                    Console.WriteLine("Endereço não fornecido");
                }
                
                Console.WriteLine("Criando entidade Cliente...");
                // Criar cliente COM SENHA e CPF opcional
                Cliente cliente = null;
                try
                {
                    cliente = Cliente.Create(dto.Nome, email, cpf, dto.Senha, endereco);
                    Console.WriteLine($"Cliente criado - ID: {cliente?.IdCliente}, Nome: {cliente?.Nome}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"ERRO ao criar entidade Cliente: {ex.Message}");
                    Console.WriteLine($"StackTrace: {ex.StackTrace}");
                    throw;
                }

                Console.WriteLine("Adicionando cliente ao repositório...");
                try
                {
                    _clienteRepo.Adicionar(cliente);
                    Console.WriteLine("Cliente adicionado ao repositório com sucesso");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"ERRO ao adicionar no repositório: {ex.Message}");
                    Console.WriteLine($"StackTrace: {ex.StackTrace}");
                    throw;
                }

                Console.WriteLine("Criando DTO de resposta...");
                var response = new ClienteResponseDTO
                {
                    IdCliente = cliente.IdCliente,
                    Nome = cliente.Nome,
                    Email = cliente.Email.Endereco // Pega a string do objeto Email
                };

                Console.WriteLine("=== CLIENTE CRIADO COM SUCESSO ===");
                return response;
            }
            catch (Exception ex)
            {
                // Log detalhado do erro
                Console.WriteLine($"=== ERRO AO CRIAR CLIENTE ===");
                Console.WriteLine($"Mensagem: {ex.Message}");
                Console.WriteLine($"StackTrace: {ex.StackTrace}");
                if (ex.InnerException != null)
                {
                    Console.WriteLine($"Inner Exception: {ex.InnerException.Message}");
                    Console.WriteLine($"Inner StackTrace: {ex.InnerException.StackTrace}");
                }
                Console.WriteLine($"=== FIM DO ERRO ===");
                throw new Exception($"Erro ao criar cliente: {ex.Message}");
            }
        }

        public Cliente Autenticar(string email, string senha)
        {
            var clientes = _clienteRepo.ObterTodos();
            var cliente = clientes.FirstOrDefault(c => 
                c.Email.Endereco.Equals(email, StringComparison.OrdinalIgnoreCase));

            if (cliente == null)
                return null;

            if (!cliente.VerificarSenha(senha))
                return null;

            if (!cliente.Ativo)
                throw new Exception("Usuário desativado");

            return cliente;
        }

        public bool EmailJaExiste(string email)
        {
            var clientes = _clienteRepo.ObterTodos();
            return clientes.Any(c => 
                c.Email.Endereco.Equals(email, StringComparison.OrdinalIgnoreCase));
        }

        public Cliente ObterPorId(int id)
        {
            return _clienteRepo.ObterPorId(id);
        }

        public IEnumerable<Cliente> ObterTodos()
        {
            return _clienteRepo.ObterTodos();
        }

        public void Atualizar(Cliente cliente)
        {
            _clienteRepo.Atualizar(cliente);
        }

        public void Remover(int id)
        {
            _clienteRepo.Remover(id);
        }
    }
}