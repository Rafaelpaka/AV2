using System.Text.Json;

namespace AV2.Infrastructure.Data
{
    public class JsonDatabaseService
    {
        private readonly string _dataDirectory;
        private readonly JsonSerializerOptions _jsonOptions;

        public JsonDatabaseService()
{
    // Diretório onde os arquivos JSON serão salvos
    var projectRoot = Directory.GetParent(Directory.GetCurrentDirectory())?.FullName 
                      ?? Directory.GetCurrentDirectory();
    _dataDirectory = Path.Combine(projectRoot, "DatabaseJson");
    
    // LOG para ver onde está salvando
    Console.WriteLine($"========================================");
    Console.WriteLine($"DIRETÓRIO ATUAL: {Directory.GetCurrentDirectory()}");
    Console.WriteLine($"DIRETÓRIO DOS JSON: {_dataDirectory}");
    Console.WriteLine($"========================================");
    
    // Cria o diretório se não existir
    if (!Directory.Exists(_dataDirectory))
    {
        Directory.CreateDirectory(_dataDirectory);
        Console.WriteLine($"Pasta criada: {_dataDirectory}");
    }

    // Opções de serialização (formato bonito e legível)
    _jsonOptions = new JsonSerializerOptions
    {
        WriteIndented = true,
        PropertyNameCaseInsensitive = true  // ← CORREÇÃO
    };
}

        // Ler dados de um arquivo JSON
        public async Task<T?> ReadAsync<T>(string fileName) where T : class
        {
            var filePath = Path.Combine(_dataDirectory, $"{fileName}.json");

            if (!File.Exists(filePath))
            {
                return null;
            }

            try
            {
                var jsonString = await File.ReadAllTextAsync(filePath);
                return JsonSerializer.Deserialize<T>(jsonString, _jsonOptions);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao ler arquivo {fileName}.json: {ex.Message}");
                return null;
            }
        }

        // Escrever dados em um arquivo JSON
        public async Task WriteAsync<T>(string fileName, T data) where T : class
        {
            var filePath = Path.Combine(_dataDirectory, $"{fileName}.json");

            try
            {
                var jsonString = JsonSerializer.Serialize(data, _jsonOptions);
                await File.WriteAllTextAsync(filePath, jsonString);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao escrever arquivo {fileName}.json: {ex.Message}");
                throw;
            }
        }

        // Verificar se arquivo existe
        public bool FileExists(string fileName)
        {
            var filePath = Path.Combine(_dataDirectory, $"{fileName}.json");
            return File.Exists(filePath);
        }

        // Deletar arquivo
        public void DeleteFile(string fileName)
        {
            var filePath = Path.Combine(_dataDirectory, $"{fileName}.json");
            if (File.Exists(filePath))
            {
                File.Delete(filePath);
            }
        }
    }
}