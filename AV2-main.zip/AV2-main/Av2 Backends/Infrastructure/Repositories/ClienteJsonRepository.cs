using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using AV2.Domain.Entities;
using AV2.Domain.Interfaces;
using AV2.Domain.ValueObjects;

namespace AV2.Infrastructure.Repositories
{
    public class ClienteJsonRepository : IClienteRepository
    {
        private readonly string _filePath;
        private List<ClienteDTO> _clientes;
        private int _nextId;

        public ClienteJsonRepository()
        {
            // Define o caminho do arquivo JSON
            string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
            string projectRoot = Path.GetFullPath(Path.Combine(baseDirectory, @"..\..\..\.."));
            string databaseFolder = Path.Combine(projectRoot, "DatabaseJson");
            
            // Cria a pasta se não existir
            if (!Directory.Exists(databaseFolder))
            {
                Directory.CreateDirectory(databaseFolder);
                Console.WriteLine($"Pasta DatabaseJson criada em: {databaseFolder}");
            }
            
            _filePath = Path.Combine(databaseFolder, "clientes.json");
            Console.WriteLine($"DIRETÓRIO ATUAL: {Directory.GetCurrentDirectory()}");
            Console.WriteLine($"DIRETÓRIO DOS JSON: {databaseFolder}");
            Console.WriteLine($"========================================");
            
            LoadData();
        }

        private void LoadData()
        {
            try
            {
                if (File.Exists(_filePath))
                {
                    string json = File.ReadAllText(_filePath);
                    _clientes = JsonSerializer.Deserialize<List<ClienteDTO>>(json) ?? new List<ClienteDTO>();
                    _nextId = _clientes.Any() ? _clientes.Max(c => c.Id) + 1 : 1;
                    Console.WriteLine($"Clientes carregados: {_clientes.Count}");
                }
                else
                {
                    _clientes = new List<ClienteDTO>();
                    _nextId = 1;
                    SaveData();
                    Console.WriteLine("Arquivo de clientes criado.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao carregar dados: {ex.Message}");
                _clientes = new List<ClienteDTO>();
                _nextId = 1;
            }
        }

        private void SaveData()
        {
            try
            {
                var options = new JsonSerializerOptions { WriteIndented = true };
                string json = JsonSerializer.Serialize(_clientes, options);
                File.WriteAllText(_filePath, json);
                Console.WriteLine($"Dados salvos: {_clientes.Count} clientes");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao salvar dados: {ex.Message}");
                throw;
            }
        }

        public void Adicionar(Cliente cliente)
        {
            try
            {
                Console.WriteLine("Convertendo Cliente para ClienteDTO...");
                var dto = ClienteDTO.FromEntity(cliente, _nextId);
                Console.WriteLine($"DTO criado - ID: {dto.Id}, Nome: {dto.Nome}, CPF: {dto.CPF ?? "null"}");
                
                _clientes.Add(dto);
                _nextId++;
                SaveData();
                
                // Atualiza o ID da entidade
                typeof(Cliente).GetProperty("IdCliente")?.SetValue(cliente, dto.Id);
                Console.WriteLine($"Cliente adicionado com ID: {dto.Id}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro em Adicionar: {ex.Message}");
                Console.WriteLine($"StackTrace: {ex.StackTrace}");
                throw;
            }
        }

        public void Atualizar(Cliente cliente)
        {
            var dto = _clientes.FirstOrDefault(c => c.Id == cliente.IdCliente);
            if (dto == null)
                throw new Exception("Cliente não encontrado");

            var updated = ClienteDTO.FromEntity(cliente, cliente.IdCliente);
            int index = _clientes.IndexOf(dto);
            _clientes[index] = updated;
            SaveData();
        }

        public void Remover(int id)
        {
            var dto = _clientes.FirstOrDefault(c => c.Id == id);
            if (dto != null)
            {
                _clientes.Remove(dto);
                SaveData();
            }
        }

        public Cliente ObterPorId(int id)
        {
            var dto = _clientes.FirstOrDefault(c => c.Id == id);
            return dto?.ToEntity();
        }

        public IEnumerable<Cliente> ObterTodos()
        {
            return _clientes.Select(dto => dto.ToEntity()).ToList();
        }

        // DTO interno para serialização JSON
        private class ClienteDTO
        {
            public int Id { get; set; }
            public required string Nome { get; set; }
            public required string Email { get; set; }
            public required string Senha { get; set; }
            public string? CPF { get; set; } // OPCIONAL - pode ser null
            public EnderecoDTO? Endereco { get; set; }
            public DateTime DataCadastro { get; set; }
            public bool Ativo { get; set; }

            public static ClienteDTO FromEntity(Cliente cliente, int id)
            {
                try
                {
                    Console.WriteLine($"FromEntity - Convertendo cliente: {cliente?.Nome}");
                    Console.WriteLine($"FromEntity - Email: {cliente?.Email?.Endereco}");
                    Console.WriteLine($"FromEntity - CPF é null? {cliente?.CPF == null}");
                    
                    return new ClienteDTO
                    {
                        Id = id,
                        Nome = cliente.Nome,
                        Email = cliente.Email.Endereco,
                        Senha = cliente.Senha,
                        CPF = cliente.CPF?.Numero, // Usa ?. para evitar null reference
                        Endereco = cliente.Endereco != null ? EnderecoDTO.FromEntity(cliente.Endereco) : null,
                        DataCadastro = cliente.DataCadastro,
                        Ativo = cliente.Ativo
                    };
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Erro em FromEntity: {ex.Message}");
                    Console.WriteLine($"Cliente Nome: {cliente?.Nome}");
                    Console.WriteLine($"Cliente Email: {cliente?.Email?.Endereco}");
                    Console.WriteLine($"Cliente CPF: {cliente?.CPF?.Numero ?? "null"}");
                    throw;
                }
            }

            public Cliente ToEntity()
            {
                // Cria o objeto Email a partir da string
                var email = Domain.ValueObjects.Email.Create(this.Email);
                
                // Cria CPF apenas se não for null
                CPF cpf = null;
                if (!string.IsNullOrWhiteSpace(this.CPF))
                {
                    try
                    {
                        cpf = Domain.ValueObjects.CPF.Create(this.CPF);
                    }
                    catch
                    {
                        cpf = null;
                    }
                }

                // Cria Endereco se não for null
                Domain.ValueObjects.Endereco? endereco = null;
                if (this.Endereco != null)
                {
                    endereco = this.Endereco.ToEntity();
                }

                // Cria o cliente
                var cliente = Cliente.Create(this.Nome, email, cpf, this.Senha, endereco);
                
                // Define o ID usando reflexão
                typeof(Cliente).GetProperty("IdCliente")?.SetValue(cliente, this.Id);
                typeof(Cliente).GetProperty("DataCadastro")?.SetValue(cliente, this.DataCadastro);
                
                if (!this.Ativo)
                {
                    typeof(Cliente).GetProperty("Ativo")?.SetValue(cliente, false);
                }

                return cliente;
            }
        }

        private class EnderecoDTO
        {
            public required string Logradouro { get; set; }
            public required string Numero { get; set; }
            public required string Bairro { get; set; }
            public required string Cidade { get; set; }
            public required string Estado { get; set; }
            public required string CEP { get; set; }
            public string? Complemento { get; set; }

            public static EnderecoDTO FromEntity(Endereco endereco)
            {
                return new EnderecoDTO
                {
                    Logradouro = endereco.Logradouro,
                    Numero = endereco.Numero,
                    Bairro = endereco.Bairro,
                    Cidade = endereco.Cidade,
                    Estado = endereco.Estado,
                    CEP = endereco.CEP,
                    Complemento = endereco.Complemento
                };
            }

            public Domain.ValueObjects.Endereco ToEntity()
            {
                return Domain.ValueObjects.Endereco.Create(
                    this.Logradouro, 
                    this.Numero, 
                    this.Bairro, 
                    this.Cidade, 
                    this.Estado, 
                    this.CEP, 
                    this.Complemento
                );
            }
        }
    }
}