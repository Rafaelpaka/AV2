using System;
using System.Collections.Generic;
using System.Linq;
using AV2.Domain.Entities;
using AV2.Domain.Interfaces;
using AV2.Infrastructure.Data;

namespace AV2.Infrastructure.Repositories
{
    public class ProdutoJsonRepository : IProdutoRepository
    {
        private readonly JsonDatabaseService _db;
        private const string FileName = "produtos";
        private List<ProdutoDTO> _produtos = new();
        private int _proximoId;

        public ProdutoJsonRepository(JsonDatabaseService db)
        {
            _db = db;
            CarregarDados();
        }

        private void CarregarDados()
        {
            var data = _db.ReadAsync<DatabaseWrapper>(FileName).Result;
            
            if (data == null || data.Produtos == null)
            {
                _produtos = new List<ProdutoDTO>();
                _proximoId = 1;
                SalvarDados();
            }
            else
            {
                _produtos = data.Produtos;
                _proximoId = _produtos.Any() ? _produtos.Max(p => p.IdProduto) + 1 : 1;
            }
        }

        private void SalvarDados()
        {
            var data = new DatabaseWrapper { Produtos = _produtos };
            _db.WriteAsync(FileName, data).Wait();
        }

        public Produto ObterPorId(int idProduto)
        {
            var dto = _produtos.FirstOrDefault(p => p.IdProduto == idProduto);
            return dto?.ToEntity();
        }

        public IEnumerable<Produto> ObterTodos()
        {
            return _produtos.Where(p => p.Ativo).Select(dto => dto.ToEntity());
        }

        public IEnumerable<Produto> ObterPorCategoria(string categoria)
        {
            return _produtos
                .Where(p => p.Ativo && p.Categoria.Equals(categoria, StringComparison.OrdinalIgnoreCase))
                .Select(dto => dto.ToEntity());
        }

        public void Adicionar(Produto produto)
        {
            var dto = ProdutoDTO.FromEntity(produto, _proximoId++);
            _produtos.Add(dto);
            SalvarDados();
        }

        public void Atualizar(Produto produto)
        {
            var dto = _produtos.FirstOrDefault(p => p.IdProduto == produto.IdProduto);
            if (dto != null)
            {
                _produtos.Remove(dto);
                _produtos.Add(ProdutoDTO.FromEntity(produto, produto.IdProduto));
                SalvarDados();
            }
        }

        public void Remover(int idProduto)
        {
            var dto = _produtos.FirstOrDefault(p => p.IdProduto == idProduto);
            if (dto != null)
            {
                _produtos.Remove(dto);
                SalvarDados();
            }
        }

        // DTO para serialização JSON
        private class ProdutoDTO
        {
            public int IdProduto { get; set; }
            public string Nome { get; set; } = string.Empty;
            public string Descricao { get; set; } = string.Empty;
            public decimal Preco { get; set; }
            public string Categoria { get; set; } = string.Empty;
            public string Image { get; set; } = "https://via.placeholder.com/400x300?text=Sem+Imagem";
            public int Estoque { get; set; }
            public bool Ativo { get; set; }
            public double Rating { get; set; }
            public int Reviews { get; set; }
            public DateTime DataCriacao { get; set; }

            public static ProdutoDTO FromEntity(Produto produto, int id)
            {
                return new ProdutoDTO
                {
                    IdProduto = id,
                    Nome = produto.Nome,
                    Descricao = produto.Descricao,
                    Preco = produto.PrecoDecimal,
                    Categoria = produto.Categoria,
                    Image = produto.Image ?? "https://via.placeholder.com/400x300?text=Sem+Imagem",
                    Estoque = produto.Estoque,
                    Ativo = produto.Ativo,
                    Rating = produto.Rating,
                    Reviews = produto.Reviews,
                    DataCriacao = produto.DataCriacao
                };
            }

            public Produto ToEntity()
            {
                var produto = (Produto)Activator.CreateInstance(typeof(Produto), true);
                
                typeof(Produto).GetProperty("IdProduto")?.SetValue(produto, IdProduto);
                typeof(Produto).GetProperty("Nome")?.SetValue(produto, Nome);
                typeof(Produto).GetProperty("Descricao")?.SetValue(produto, Descricao);
                typeof(Produto).GetProperty("Preco")?.SetValue(produto, AV2.Domain.ValueObjects.Dinheiro.Create(Preco));
                typeof(Produto).GetProperty("Categoria")?.SetValue(produto, Categoria);
                typeof(Produto).GetProperty("Image")?.SetValue(produto, Image ?? "https://via.placeholder.com/400x300?text=Sem+Imagem");
                typeof(Produto).GetProperty("Estoque")?.SetValue(produto, Estoque);
                typeof(Produto).GetProperty("Ativo")?.SetValue(produto, Ativo);
                typeof(Produto).GetProperty("Rating")?.SetValue(produto, Rating);
                typeof(Produto).GetProperty("Reviews")?.SetValue(produto, Reviews);
                typeof(Produto).GetProperty("DataCriacao")?.SetValue(produto, DataCriacao);
                
                return produto;
            }
        }

        private class DatabaseWrapper
        {
            public List<ProdutoDTO> Produtos { get; set; } = new();
        }
    }
}