using System;
using System.Collections.Generic;
using System.Linq;
using AV2.Domain.Entities;
using AV2.Domain.Interfaces;
using AV2.Infrastructure.Data;

namespace AV2.Infrastructure.Repositories
{
    public class CarrinhoJsonRepository : ICarrinhoRepository
    {
        private readonly JsonDatabaseService _db;
        private readonly IProdutoRepository _produtoRepository;
        private const string FileName = "carrinhos";
        private List<CarrinhoDTO> _carrinhos = new();
        private int _proximoId;

        public CarrinhoJsonRepository(JsonDatabaseService db, IProdutoRepository produtoRepository)
        {
            _db = db;
            _produtoRepository = produtoRepository;
            CarregarDados();
        }

        private void CarregarDados()
        {
            var data = _db.ReadAsync<DatabaseWrapper>(FileName).Result;
            
            if (data == null || data.Carrinhos == null)
            {
                _carrinhos = new List<CarrinhoDTO>();
                _proximoId = 1;
                SalvarDados();
            }
            else
            {
                _carrinhos = data.Carrinhos;
                _proximoId = _carrinhos.Any() ? _carrinhos.Max(c => c.IdCarrinho) + 1 : 1;
            }
        }

        private void SalvarDados()
        {
            var data = new DatabaseWrapper { Carrinhos = _carrinhos };
            _db.WriteAsync(FileName, data).Wait();
        }

        public Carrinho ObterPorId(int idCarrinho)
        {
            var dto = _carrinhos.FirstOrDefault(c => c.IdCarrinho == idCarrinho);
            return dto?.ToEntity(_produtoRepository);
        }

        public IEnumerable<Carrinho> ObterPorCliente(int idCliente)
        {
            return _carrinhos
                .Where(c => c.IdCliente == idCliente)
                .Select(dto => dto.ToEntity(_produtoRepository));
        }

        public void Adicionar(Carrinho carrinho)
        {
            var dto = CarrinhoDTO.FromEntity(carrinho, _proximoId++);
            _carrinhos.Add(dto);
            SalvarDados();
        }

        public void Atualizar(Carrinho carrinho)
        {
            var dto = _carrinhos.FirstOrDefault(c => c.IdCarrinho == carrinho.IdCarrinho);
            if (dto != null)
            {
                _carrinhos.Remove(dto);
                _carrinhos.Add(CarrinhoDTO.FromEntity(carrinho, carrinho.IdCarrinho));
                SalvarDados();
            }
        }

        public void Remover(int idCarrinho)
        {
            var dto = _carrinhos.FirstOrDefault(c => c.IdCarrinho == idCarrinho);
            if (dto != null)
            {
                _carrinhos.Remove(dto);
                SalvarDados();
            }
        }

        // DTO para serialização JSON
        private class CarrinhoDTO
        {
            public int IdCarrinho { get; set; }
            public int IdCliente { get; set; }
            public DateTime DataCriacao { get; set; }
            public DateTime? DataExpiracao { get; set; }
            public List<ItemCarrinhoDTO> Itens { get; set; } = new();

            public static CarrinhoDTO FromEntity(Carrinho carrinho, int id)
            {
                return new CarrinhoDTO
                {
                    IdCarrinho = id,
                    IdCliente = carrinho.IdCliente,
                    DataCriacao = carrinho.DataCriacao,
                    DataExpiracao = carrinho.DataExpiracao,
                    Itens = carrinho.Itens.Select(i => new ItemCarrinhoDTO
                    {
                        IdProduto = i.IdProduto,
                        Quantidade = i.Quantidade,
                        PrecoUnitario = i.PrecoUnitarioDecimal
                    }).ToList()
                };
            }

            public Carrinho ToEntity(IProdutoRepository produtoRepository)
            {
                var carrinho = (Carrinho)Activator.CreateInstance(typeof(Carrinho), true);
                
                typeof(Carrinho).GetProperty("IdCarrinho")?.SetValue(carrinho, IdCarrinho);
                typeof(Carrinho).GetProperty("IdCliente")?.SetValue(carrinho, IdCliente);
                typeof(Carrinho).GetProperty("DataCriacao")?.SetValue(carrinho, DataCriacao);
                typeof(Carrinho).GetProperty("DataExpiracao")?.SetValue(carrinho, DataExpiracao);
                
                // Reconstruir os itens do carrinho
                foreach (var itemDto in Itens)
                {
                    var produto = produtoRepository.ObterPorId(itemDto.IdProduto);
                    if (produto != null)
                    {
                        carrinho.AdicionarProduto(produto, itemDto.Quantidade);
                    }
                }
                
                return carrinho;
            }
        }

        private class ItemCarrinhoDTO
        {
            public int IdProduto { get; set; }
            public int Quantidade { get; set; }
            public decimal PrecoUnitario { get; set; }
        }

        private class DatabaseWrapper
        {
            public List<CarrinhoDTO> Carrinhos { get; set; } = new();
        }
    }
}