using AV2.Application.Services;
using AV2.Domain.Interfaces;
using AV2.Infrastructure.Repositories;        
using AV2.Infrastructure.Data;

var builder = WebApplication.CreateBuilder(args);

// Adicionar serviços
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Registrar o serviço de banco de dados JSON
builder.Services.AddSingleton<JsonDatabaseService>();

// Registrar os repositórios como Singleton para manter dados em memória
builder.Services.AddSingleton<IProdutoRepository, ProdutoJsonRepository>();
builder.Services.AddSingleton<IClienteRepository, ClienteJsonRepository>();
builder.Services.AddSingleton<ICarrinhoRepository, CarrinhoJsonRepository>();

// Registrar os serviços de aplicação
builder.Services.AddScoped<ProdutoService>();
builder.Services.AddScoped<ClienteService>();
builder.Services.AddScoped<CarrinhoService>();
builder.Services.AddScoped<ClienteService>();
builder.Services.AddScoped<ProdutoService>();

// Configure o CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowFrontend", policy =>
    {
        policy.WithOrigins("http://localhost:5173")
              .AllowAnyHeader()
              .AllowAnyMethod()
              .AllowCredentials();
    });
});

var app = builder.Build();

// Configure o pipeline HTTP
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors("AllowFrontend");
app.UseAuthorization();
app.MapControllers();

app.MapGet("/", () => "API funcionando! Os dados estão sendo salvos em arquivos JSON.");

app.Run();