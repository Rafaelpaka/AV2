
using Microsoft.AspNetCore.Mvc;
using AV2.Application.Services;
using AV2.Domain.ValueObjects;

namespace AV2.Application.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProdutoController : ControllerBase
    {
        private readonly ProdutoService _produtoService;

        public ProdutoController(ProdutoService produtoService)
        {
            _produtoService = produtoService;
        }

        [HttpGet]
        public ActionResult<IEnumerable<ProdutoDTO>> GetProdutos()
        {
            var produtos = _produtoService.ObterTodos();
            var produtosDto = produtos.Select(p => new ProdutoDTO
            {
                Id = p.IdProduto,
                Name = p.Nome,
                Price = p.PrecoDecimal,
                Description = p.Descricao,
                Category = p.Categoria,
                Image = p.Image,
                Rating = p.Rating,
                Reviews = p.Reviews
            });
            
            return Ok(produtosDto);
        }

        [HttpGet("{id}")]
        public ActionResult<ProdutoDTO> GetProduto(int id)
        {
            var produto = _produtoService.ObterPorId(id);
            if (produto == null)
            {
                return NotFound(new { message = "Produto não encontrado" });
            }

            var produtoDto = new ProdutoDTO
            {
                Id = produto.IdProduto,
                Name = produto.Nome,
                Price = produto.PrecoDecimal,
                Description = produto.Descricao,
                Category = produto.Categoria,
                Image = produto.Image,
                Rating = produto.Rating,
                Reviews = produto.Reviews
            };

            return Ok(produtoDto);
        }

        [HttpPost]
        public ActionResult<ProdutoDTO> CreateProduto([FromBody] ProdutoCreateDTO dto)
        {
            try
            {
                _produtoService.CriarProduto(
                    dto.Name ?? "Produto sem nome",
                    dto.Description ?? "Sem descrição",
                    dto.Price,
                    dto.Category ?? "Geral",
                    dto.EstoqueInicial > 0 ? dto.EstoqueInicial : 10,
                    dto.Image,
                    dto.Rating,
                    dto.Reviews
                );

                return Ok(new { message = "Produto criado com sucesso!" });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpPut("{id}")]
        public ActionResult AtualizarProduto(int id, [FromBody] ProdutoUpdateDTO dto)
        {
            try
            {
                var produto = _produtoService.ObterPorId(id);
                if (produto == null)
                    return NotFound(new { message = "Produto não encontrado" });

                if (!string.IsNullOrEmpty(dto.Name))
                    produto.AlterarNome(dto.Name);
                
                if (!string.IsNullOrEmpty(dto.Description))
                    produto.AlterarDescricao(dto.Description);
                
                if (dto.Price > 0)
                    produto.AlterarPreco(Dinheiro.Create(dto.Price));
                
                if (!string.IsNullOrEmpty(dto.Category))
                    produto.AlterarCategoria(dto.Category);
                
                if (!string.IsNullOrEmpty(dto.Image))
                    produto.AlterarImagem(dto.Image);

                _produtoService.AtualizarProduto(produto);

                return Ok(new { message = "Produto atualizado com sucesso!" });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpDelete("{id}")]
        public ActionResult DeletarProduto(int id)
        {
            try
            {
                _produtoService.RemoverProduto(id);
                return Ok(new { message = "Produto removido com sucesso!" });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpPost("{id}/estoque/adicionar")]
        public ActionResult AdicionarEstoque(int id, [FromBody] EstoqueDTO dto)
        {
            try
            {
                _produtoService.AdicionarEstoque(id, dto.Quantidade);
                return Ok(new { message = $"{dto.Quantidade} unidades adicionadas ao estoque" });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpPost("{id}/estoque/remover")]
        public ActionResult RemoverEstoque(int id, [FromBody] EstoqueDTO dto)
        {
            try
            {
                _produtoService.RemoverEstoque(id, dto.Quantidade);
                return Ok(new { message = $"{dto.Quantidade} unidades removidas do estoque" });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }
    }

    // DTOs
    public class ProdutoDTO
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public decimal Price { get; set; }
        public string? Description { get; set; }
        public string? Category { get; set; }
        public string? Image { get; set; }
        public double Rating { get; set; }
        public int Reviews { get; set; }
    }

    public class ProdutoCreateDTO
    {
        public string? Name { get; set; }
        public decimal Price { get; set; }
        public string? Description { get; set; }
        public string? Category { get; set; }
        public string? Image { get; set; }
        public double Rating { get; set; } = 0;
        public int Reviews { get; set; } = 0;
        public int EstoqueInicial { get; set; } = 10;
    }

    public class ProdutoUpdateDTO
    {
        public string? Name { get; set; }
        public decimal Price { get; set; }
        public string? Description { get; set; }
        public string? Category { get; set; }
        public string? Image { get; set; }
        public bool Ativo { get; set; } = true;
    }

    public class EstoqueDTO
    {
        public int Quantidade { get; set; }
    }
}