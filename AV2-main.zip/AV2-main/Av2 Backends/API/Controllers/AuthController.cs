using Microsoft.AspNetCore.Mvc;
using AV2.Application.Services;
using AV2.Application.DTOs.ClienteDTOs;

namespace AV2.Application.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly ClienteService _clienteService;

        public AuthController(ClienteService clienteService)
        {
            _clienteService = clienteService;
        }

        [HttpPost("register")]
        public ActionResult Register([FromBody] RegisterDTO dto)
        {
            try
            {
                var clienteDto = new ClienteCreateDTO
                {
                    Nome = dto.Nome,
                    Email = dto.Email,
                    CPF = dto.CPF, // Passa null se não fornecido
                    Senha = dto.Senha
                };

                var resultado = _clienteService.CriarCliente(clienteDto);

                return Ok(new
                {
                    message = "Usuário criado com sucesso!",
                    user = new
                    {
                        id = resultado.IdCliente,
                        nome = resultado.Nome,
                        email = resultado.Email
                    }
                });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpPost("login")]
        public ActionResult Login([FromBody] LoginDTO dto)
        {
            try
            {
                var cliente = _clienteService.Autenticar(dto.Email, dto.Senha);

                if (cliente == null)
                {
                    return Unauthorized(new { message = "Email ou senha inválidos" });
                }

                return Ok(new
                {
                    message = "Login realizado com sucesso!",
                    user = new
                    {
                        id = cliente.IdCliente,
                        nome = cliente.Nome,
                        email = cliente.Email.Endereco
                    }
                });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpPost("check-email")]
        public ActionResult CheckEmail([FromBody] CheckEmailDTO dto)
        {
            var existe = _clienteService.EmailJaExiste(dto.Email);
            return Ok(new { exists = existe });
        }
    }

    // DTOs
    public class RegisterDTO
    {
        public string Nome { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string? CPF { get; set; } // Opcional - pode ser null
        public string Senha { get; set; } = string.Empty;
    }

    public class LoginDTO
    {
        public string Email { get; set; } = string.Empty;
        public string Senha { get; set; } = string.Empty;
    }

    public class CheckEmailDTO
    {
        public string Email { get; set; } = string.Empty;
    }
}