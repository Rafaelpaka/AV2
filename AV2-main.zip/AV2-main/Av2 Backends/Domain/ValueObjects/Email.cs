using System;
using System.Text.RegularExpressions;
using AV2.Domain.Exceptions;

namespace AV2.Domain.ValueObjects
{
    public class Email
    {
        public string Endereco { get; private set; }

        // Construtor privado para forçar uso do método Create
        private Email() { }

        public static Email Create(string endereco)
        {
            if (string.IsNullOrWhiteSpace(endereco))
                throw new ValidacaoException("Email", "Email não pode ser vazio.");

            // Remove espaços em branco
            endereco = endereco.Trim();

            // Validação básica de formato de email
            var regex = new Regex(@"^[^@\s]+@[^@\s]+\.[^@\s]+$");
            if (!regex.IsMatch(endereco))
                throw new ValidacaoException("Email", "Formato de email inválido.");

            return new Email { Endereco = endereco.ToLower() };
        }

        public override bool Equals(object obj)
        {
            if (obj is Email other)
                return Endereco.Equals(other.Endereco, StringComparison.OrdinalIgnoreCase);
            
            return false;
        }

        public override int GetHashCode()
        {
            return Endereco.ToLower().GetHashCode();
        }

        public override string ToString()
        {
            return Endereco;
        }
    }
}